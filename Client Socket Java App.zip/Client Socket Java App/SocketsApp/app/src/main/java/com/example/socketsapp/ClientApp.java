package com.example.socketsapp;

import java.net.*;
import java.io.*;
import android.os.AsyncTask;


public class ClientApp{

    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    public void startConnection(String ip, int port) throws IOException
    {

        clientSocket = new Socket(ip, port);

    }

    public String sendMessage(String msg) throws IOException
    {
        String resp = in.readLine();
        return resp;
    }

    public void stopConn() throws IOException
    {
        in.close();
        out.close();
        clientSocket.close();
    }

    public static void main(String[] args) throws IOException
    {
        ClientApp client = new ClientApp();
        client.startConnection("172.16.44.46", 9999);
    }
}
