See the included Java file... ClientApp.java, MainActivity.java, acativity_main.xml, 
AndroidManifest.xml

Even though it compiles without errors, it needs some work.

The program is intended to create a client socket when the user clicks a button in an Android app.

The server socker side was built using a simple python script from class.

For testing purposes, the server socket script was executed in a Kali Linux VM.

In the current stage the program execute with run-time errors.

Once the user presses the button, the program fails to handle a NetworkOnMainThreadException exception,which could be mitigated by implementing the ClientApp class to extend AsyncTask<>.

OR... it could also be mitigated by creating a thread to handle networking functions. 

The activity_main.xml was included with the button functionality.

The AndroidManifest.xml was also added with the right permission included.
